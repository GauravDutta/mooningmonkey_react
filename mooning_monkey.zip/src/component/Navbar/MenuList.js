export const MenuList = [
    {
        title:"Home",
        url:'/'
    },
    {
        title:"Buy Now",
        url:'/buy_now'
    },
    {
        title:"Tak Token",
        url:'/nft-utility-token-tak'
    },
  
    {
        title:"Learn More",
        url:'/learn_more'
    },
    {
        title: <img src='https://mooningmonkey.com/wp-content/uploads/2021/10/logo-final-rocket2.png' />,
        url:'/'
    },
    {
        title:"Evolution Lab",
        url:'/nft-evolution'
    },
    {
        title:"Comics",
        url:'/comic-book'
    },
    {
        title:"Calculator",
        url:'/nft-calculator'
    },
    {
        title:"Attributes",
        url:'/attributes'
    }
]