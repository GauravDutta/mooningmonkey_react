import React from 'react'
import { Link } from 'react-router-dom';
import { MenuList } from "./MenuList";


function NavbarMenu() {
    const getMenuList = MenuList.map(({url,title},i) => {
        return(
            <li key={i}>
            
            <Link  to={url}>{title}</Link>
          
            </li>
        );
    });
    return (
      <nav className=''>
<ul>
    {getMenuList}
</ul>
      </nav>  
    )
}

export default NavbarMenu


