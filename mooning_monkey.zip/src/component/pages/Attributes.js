import React from 'react'

function Attributes() {
    return (
        <div>
                this is Attribute page
        </div>
    )
}

export default Attributes
