import React from 'react'

function BuyNow() {
    return (
        <div>
            this is Buy Now Page
        </div>
    )
}

export default BuyNow
