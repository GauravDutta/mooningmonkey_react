import React from 'react'
import Calculator from './calculator';
import './calculator.css';  
import './style-calculator.css';  


function index() {
return(
    <Calculator/>
) 
}
export default index; 
