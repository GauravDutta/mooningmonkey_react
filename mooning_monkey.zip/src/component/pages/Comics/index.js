import React from 'react'
import Comics from './Comics';
import './comics.css';


function index() {
return(
    <Comics/>
) 
}
export default index; 