import React from 'react'
import Home from './Home';



function index() {
return(
    <Home/>
)
}
export default index;