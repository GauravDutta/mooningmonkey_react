import React from 'react'

function LearnMore() {
    return (
        <div>
                this is LearnMore
        </div>
    )
}

export default LearnMore
