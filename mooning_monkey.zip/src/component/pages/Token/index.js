import React from 'react'
import Token from './Token';
import './token.css';


function index() {
return(
    <Token/>
)
}
export default index;