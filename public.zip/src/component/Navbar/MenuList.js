export const MenuList = [
    
   { "left_side":
    [
        {
            title:"Home",
            url:'/'
        },
        {
            title:"Buy Now",
            url:'/buy_now'
        },
        {
            title:"Tak Token",
            url:'/nft-utility-token-tak'
        },
      
        {
            title:"Learn More",
            url:'/learn_more'
        },
    ],
    
   
        "right_side": [
        {
            title:"Evolution Lab",
            url:'/nft-evolution'
        },
        {
            title:"Comics",
            url:'/comic-book'
        },
        {
            title:"Calculator",
            url:'/nft-calculator'
        },
        {
            title:"Attributes",
            url:'/attributes'
        }
    ]}
    
]