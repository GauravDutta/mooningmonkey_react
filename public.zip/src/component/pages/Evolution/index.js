import React from 'react'
import Evolution from './Evolution';
import './evolution.css';


function index() {
return(
    <Evolution/>
)
}
export default index; 